Lechat Thomas
Dinsenmeyer Alice
année universitaire 2014-2015
Encadrant Olivier Richoux

Projet: Caractérisation d'un réseau périodique dans lequel ce propage des ondes acoustiques. Le réseaux est composés de résonateurs de Helmholtz et de guides d'ondes. Dans un second temps, du désordre est ajouté.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ce repertoire contient le code utile à l'analyse d'un reseau chaotique



=============================================================================
Comment ça marche
-----------------

- Rentrer les paramètres du réseaux dans le fichier de configuration puis exécuter main.m sous octave.
- Utiliser le script bash pour sauvegarder les figures ensuite si besoin =>  "./sauvegarde nom_de_la_save nb_de_figures" 




==============================================================================
format du fichier de configuration :
------------------------------------
1 => tube                1 | longueur | section
2 => résonateur		 2 | hauteur cavité | hauteur col | section cavite | section col




==============================================================================


Remarques diverses :
--------------------
Les coefficients de transmission et reflexion ne sont valables que pour une terminaison anéchoïque. Si ce n'est pas le cas,
ils doivent être recalculés autrement. 


